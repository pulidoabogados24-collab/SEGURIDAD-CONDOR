import { Outlet } from 'react-router-dom'
import { AppShell } from '../../components/layout/AppShell'
import { IconHome, IconAlert } from '../../components/ui/icons'

export function SupervisorLayout() {
  return (
    <AppShell
      nav={[
        { to: '/supervisor', label: 'Centro de operaciones', icon: <IconHome /> },
        { to: '/supervisor/alertas', label: 'Alertas', icon: <IconAlert /> },
        { to: '/supervisor/incidencias', label: 'Incidencias', icon: <IconAlert /> },
      ]}
    >
      <Outlet />
    </AppShell>
  )
}
