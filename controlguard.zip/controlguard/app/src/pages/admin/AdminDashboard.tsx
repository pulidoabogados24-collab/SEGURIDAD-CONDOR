import { useEffect, useState } from 'react'
import { supabase } from '../../lib/supabase/client'
import { useAuthStore } from '../../lib/stores/auth'
import { Card } from '../../components/ui/Card'
import { Badge } from '../../components/ui/Badge'
import { ALERT_TYPE_LABELS } from '../../lib/types/domain'
import type { Alert } from '../../lib/types/domain'

interface Overview {
  activeServices: number
  guardsOnDuty: number
  routesToday: number
  routesCompleted: number
  openIncidents: number
  openAlerts: number
}

export function AdminDashboard() {
  const companyId = useAuthStore((s) => s.profile?.company_id)
  const [overview, setOverview] = useState<Overview | null>(null)
  const [alerts, setAlerts] = useState<Alert[]>([])
  const [liveGuards, setLiveGuards] = useState<
    { guard_name: string; service_name: string; status: string; last_point: string | null; completed: number; expected: number }[]
  >([])

  useEffect(() => {
    if (!companyId) return
    void loadOverview(companyId)
    void loadAlerts(companyId)
    void loadLive(companyId)

    const channel = supabase
      .channel('admin-ops')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'route_sessions', filter: `company_id=eq.${companyId}` }, () => {
        void loadOverview(companyId)
        void loadLive(companyId)
      })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'alerts', filter: `company_id=eq.${companyId}` }, () => {
        void loadAlerts(companyId)
      })
      .subscribe()

    return () => {
      void supabase.removeChannel(channel)
    }
  }, [companyId])

  async function loadOverview(cid: string) {
    const todayStart = new Date().toISOString().slice(0, 10)
    const [services, guards, sessionsToday] = await Promise.all([
      supabase.from('services').select('id', { count: 'exact', head: true }).eq('company_id', cid).eq('is_active', true),
      supabase.from('guards').select('id', { count: 'exact', head: true }).eq('company_id', cid).eq('is_active', true),
      supabase.from('route_sessions').select('status').eq('company_id', cid).gte('scheduled_at', todayStart),
    ])
    const sessions = sessionsToday.data ?? []
    const [incidents, alertsOpen] = await Promise.all([
      supabase.from('incidents').select('id', { count: 'exact', head: true }).eq('company_id', cid).eq('status', 'open'),
      supabase.from('alerts').select('id', { count: 'exact', head: true }).eq('company_id', cid).eq('status', 'open'),
    ])

    setOverview({
      activeServices: services.count ?? 0,
      guardsOnDuty: guards.count ?? 0,
      routesToday: sessions.length,
      routesCompleted: sessions.filter((s) => s.status === 'completed').length,
      openIncidents: incidents.count ?? 0,
      openAlerts: alertsOpen.count ?? 0,
    })
  }

  async function loadAlerts(cid: string) {
    const { data } = await supabase
      .from('alerts')
      .select('*')
      .eq('company_id', cid)
      .eq('status', 'open')
      .order('created_at', { ascending: false })
      .limit(8)
    setAlerts(data ?? [])
  }

  async function loadLive(cid: string) {
    const { data } = await supabase
      .from('route_sessions')
      .select(
        'status, completed_points, expected_points, guards(user_profiles(full_name)), services(name), started_at',
      )
      .eq('company_id', cid)
      .in('status', ['in_progress', 'scheduled'])
      .order('scheduled_at', { ascending: true })
      .limit(10)

    setLiveGuards(
      (data ?? []).map((r) => {
        const guardObj = Array.isArray(r.guards) ? r.guards[0] : r.guards
        const profileObj = guardObj && Array.isArray(guardObj.user_profiles) ? guardObj.user_profiles[0] : guardObj?.user_profiles
        const serviceObj = Array.isArray(r.services) ? r.services[0] : r.services
        return {
          guard_name: profileObj?.full_name ?? 'Vigilante',
          service_name: serviceObj?.name ?? 'Servicio',
          status: r.status,
          last_point: null,
          completed: r.completed_points,
          expected: r.expected_points,
        }
      }),
    )
  }

  return (
    <div className="p-8">
      <h1 className="text-lg font-semibold text-ink-50">Centro de Operaciones</h1>
      <p className="mt-1 text-sm text-ink-400">Vista en tiempo real de tu operación.</p>

      {overview && (
        <div className="mt-6 grid grid-cols-2 gap-4 lg:grid-cols-6">
          <Metric label="Servicios activos" value={overview.activeServices} />
          <Metric label="Vigilantes activos" value={overview.guardsOnDuty} />
          <Metric label="Rondas hoy" value={overview.routesToday} />
          <Metric label="Completadas" value={overview.routesCompleted} />
          <Metric label="Incidencias abiertas" value={overview.openIncidents} tone={overview.openIncidents > 0 ? 'warn' : 'ok'} />
          <Metric label="Alertas" value={overview.openAlerts} tone={overview.openAlerts > 0 ? 'danger' : 'ok'} />
        </div>
      )}

      <div className="mt-8 grid grid-cols-1 gap-6 lg:grid-cols-2">
        <Card>
          <div className="border-b border-ink-800 px-5 py-4">
            <h3 className="text-sm font-semibold text-ink-50">Operación en tiempo real</h3>
          </div>
          <div className="divide-y divide-ink-800">
            {liveGuards.length === 0 && <p className="px-5 py-6 text-sm text-ink-400">No hay rondas activas o programadas en este momento.</p>}
            {liveGuards.map((g, i) => (
              <div key={i} className="flex items-center justify-between px-5 py-3">
                <div className="flex items-center gap-3">
                  <span className={`status-dot ${g.status === 'in_progress' ? 'status-dot--ok status-dot--live' : 'status-dot--idle'}`} />
                  <div>
                    <p className="text-sm font-medium text-ink-50">{g.guard_name}</p>
                    <p className="text-xs text-ink-400">{g.service_name}</p>
                  </div>
                </div>
                <div className="text-right text-xs text-ink-400">
                  <p>{g.status === 'in_progress' ? 'En ronda' : 'Programada'}</p>
                  <p>{g.completed}/{g.expected} puntos</p>
                </div>
              </div>
            ))}
          </div>
        </Card>

        <Card>
          <div className="border-b border-ink-800 px-5 py-4">
            <h3 className="text-sm font-semibold text-ink-50">Alertas críticas</h3>
          </div>
          <div className="divide-y divide-ink-800">
            {alerts.length === 0 && <p className="px-5 py-6 text-sm text-ink-400">Sin alertas abiertas. Todo en orden.</p>}
            {alerts.map((a) => (
              <div key={a.id} className="flex items-start justify-between gap-3 px-5 py-3">
                <div>
                  <p className="text-sm font-medium text-ink-50">{ALERT_TYPE_LABELS[a.alert_type]}</p>
                  <p className="text-xs text-ink-400">{a.message}</p>
                </div>
                <Badge tone={a.severity === 'critical' ? 'danger' : a.severity === 'high' ? 'warn' : 'idle'}>
                  {a.severity}
                </Badge>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  )
}

function Metric({ label, value, tone }: { label: string; value: number; tone?: 'ok' | 'warn' | 'danger' }) {
  const toneColor = tone === 'danger' ? 'text-danger-400' : tone === 'warn' ? 'text-warn-400' : 'text-ink-50'
  return (
    <Card className="p-4">
      <p className="text-xs font-medium uppercase tracking-wide text-ink-500">{label}</p>
      <p className={`mt-1.5 text-2xl font-semibold ${toneColor}`}>{value}</p>
    </Card>
  )
}
