import { Outlet } from 'react-router-dom'
import { AppShell } from '../../components/layout/AppShell'
import { IconHome, IconBuilding, IconUsers, IconAlert, IconReport } from '../../components/ui/icons'

export function AdminLayout() {
  return (
    <AppShell
      nav={[
        { to: '/admin', label: 'Centro de operaciones', icon: <IconHome /> },
        { to: '/admin/servicios', label: 'Servicios', icon: <IconBuilding /> },
        { to: '/admin/vigilantes', label: 'Vigilantes', icon: <IconUsers /> },
        { to: '/admin/usuarios', label: 'Usuarios', icon: <IconUsers /> },
        { to: '/admin/incidencias', label: 'Incidencias', icon: <IconAlert /> },
        { to: '/admin/reportes', label: 'Reportes', icon: <IconReport /> },
      ]}
    >
      <Outlet />
    </AppShell>
  )
}
