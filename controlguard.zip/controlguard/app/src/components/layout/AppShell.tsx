import { type ReactNode } from 'react'
import { NavLink, useNavigate } from 'react-router-dom'
import clsx from 'clsx'
import { useAuthStore } from '../../lib/stores/auth'
import { ROLE_LABELS } from '../../lib/types/domain'

interface NavItem {
  to: string
  label: string
  icon: ReactNode
}

export function AppShell({ nav, children }: { nav: NavItem[]; children: ReactNode }) {
  const { profile, signOut } = useAuthStore()
  const navigate = useNavigate()

  async function handleSignOut() {
    await signOut()
    navigate('/login')
  }

  return (
    <div className="flex min-h-screen bg-ink-950">
      <aside className="flex w-60 flex-shrink-0 flex-col border-r border-ink-800 bg-ink-900">
        <div className="flex items-center gap-2 border-b border-ink-800 px-5 py-4">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-action-500 text-sm font-bold text-ink-950">
            CG
          </div>
          <span className="text-sm font-semibold text-ink-50">ControlGuard</span>
        </div>

        <nav className="flex-1 space-y-0.5 px-3 py-4">
          {nav.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              className={({ isActive }) =>
                clsx(
                  'flex items-center gap-2.5 rounded-lg px-3 py-2 text-sm font-medium transition-colors',
                  isActive ? 'bg-action-500/15 text-action-400' : 'text-ink-300 hover:bg-ink-800 hover:text-ink-100',
                )
              }
              end={item.to.split('/').length <= 2}
            >
              {item.icon}
              {item.label}
            </NavLink>
          ))}
        </nav>

        <div className="border-t border-ink-800 px-4 py-3">
          <p className="truncate text-xs font-medium text-ink-100">{profile?.full_name}</p>
          <p className="text-xs text-ink-500">{profile && ROLE_LABELS[profile.role]}</p>
          <button
            onClick={handleSignOut}
            className="mt-2 text-xs font-medium text-ink-400 hover:text-danger-400"
          >
            Cerrar sesión
          </button>
        </div>
      </aside>

      <main className="min-w-0 flex-1 overflow-y-auto">{children}</main>
    </div>
  )
}
